#ifndef GLOBAL_H
#define GLOBAL_H

#include <QDebug>



#endif // GLOBAL_H
